resource "aws_instance" "tf-ec2" {
  count         = var.instance_count
  ami           = var.ami_id
  instance_type = var.instance
  subnet_id     = aws_subnet.public_subnet.id   # from vpc.tf
  key_name      = aws_key_pair.generated_key.key_name
  vpc_security_group_ids = [
    aws_security_group.ec2_sg.id
  ]

  tags = {
    Name = "TfEC2-${count.index}"
  }
}

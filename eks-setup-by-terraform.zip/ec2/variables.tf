variable "ami_id" {
  type    = string
  default = "ami-02b8269d5e85954ef"
}

variable "instance" {
  type    = string
  default = "t2.micro"
}

variable "instance_count" {
  type    = number
  default = 1
}
# Create the secret in AWS Secrets Manager
resource "aws_secretsmanager_secret" "app_secrets" {
  name        = var.secret_name
  description = "Application secrets for EKS workloads"

  # Optional: Enable automatic deletion after 7 days (for testing)
  # recovery_window_in_days = 7

  # Optional: Prevent accidental deletion (recommended for production)
  # recovery_window_in_days = 30

  tags = {
    Name        = var.secret_name
    Environment = var.environment
    ManagedBy   = "terraform"
    Purpose     = "eks-application-secrets"
  }
}

# Create the secret version with actual secret values
resource "aws_secretsmanager_secret_version" "app_secrets" {
  secret_id = aws_secretsmanager_secret.app_secrets.id

  # JSON format for multiple key-value pairs
  secret_string = jsonencode({
    database_url      = "postgresql://user:password@localhost:5432/mydb"
    database_username = "myuser"
    database_password = "mypassword"
    api_key           = "your-api-key-here"
    jwt_secret        = "your-jwt-secret-here"
    redis_password    = "your-redis-password"
    smtp_username     = "smtp-user@example.com"
    smtp_password     = "your-smtp-password"
    encryption_key    = "your-encryption-key"
    oauth_client_id   = "your-oauth-client-id"
    oauth_secret      = "your-oauth-secret"
  })
}

# Outputs
output "secret_arn" {
  description = "ARN of the created secret"
  value       = aws_secretsmanager_secret.app_secrets.arn
}

output "secret_name" {
  description = "Name of the created secret"
  value       = aws_secretsmanager_secret.app_secrets.name
}

output "secret_id" {
  description = "ID of the created secret"
  value       = aws_secretsmanager_secret.app_secrets.id
}

output "secret_version_id" {
  description = "Version ID of the secret"
  value       = aws_secretsmanager_secret_version.app_secrets.version_id
}

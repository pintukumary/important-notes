# 1. Generate SSH Key Pair

resource "tls_private_key" "ssh_key" {
  algorithm = "RSA"
  rsa_bits  = 4096
}


# 2. Create AWS Key Pair from public key

resource "aws_key_pair" "generated_key" {
  key_name   = "tf-test-key"
  public_key = tls_private_key.ssh_key.public_key_openssh
}


# 3. Save Private Key Locally in .pem format (600 permission)

resource "local_file" "pem_key" {
  content         = tls_private_key.ssh_key.private_key_pem
  filename        = "${path.module}/tf-test-key.pem"
  file_permission = "0600"
}

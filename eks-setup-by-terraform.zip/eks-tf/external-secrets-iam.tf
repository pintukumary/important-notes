# External Secrets OIDC configuration (following your autoscaler pattern)
locals {
  external_secrets_oidc_issuer_url  = aws_eks_cluster.main.identity[0].oidc[0].issuer
  external_secrets_oidc_issuer_host = trimprefix(local.external_secrets_oidc_issuer_url, "https://")

  external_secrets_irsa_conditions = {
    "${local.external_secrets_oidc_issuer_host}:sub" = "system:serviceaccount:default:external-secrets-sa"
    "${local.external_secrets_oidc_issuer_host}:aud" = "sts.amazonaws.com"
  }
}

# Data source for account ID
data "aws_caller_identity" "current" {}

# IAM role for External Secrets
resource "aws_iam_role" "external_secrets_role" {
  name = "${var.cluster_name}-external-secrets-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Principal = {
          Federated = "arn:aws:iam::${data.aws_caller_identity.current.account_id}:oidc-provider/${local.external_secrets_oidc_issuer_host}"
        }
        Action = "sts:AssumeRoleWithWebIdentity"
        Condition = {
          StringEquals = local.external_secrets_irsa_conditions
        }
      }
    ]
  })
}

# IAM policy for Secrets Manager access
resource "aws_iam_policy" "external_secrets_policy" {
  name = "${var.cluster_name}-external-secrets-policy"

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "secretsmanager:GetSecretValue",
          "secretsmanager:DescribeSecret"
        ]
        Resource = "arn:aws:secretsmanager:${var.region}:${data.aws_caller_identity.current.account_id}:secret:*"
      }
    ]
  })
}

# Attach policy to role
resource "aws_iam_role_policy_attachment" "external_secrets_policy_attachment" {
  role       = aws_iam_role.external_secrets_role.name
  policy_arn = aws_iam_policy.external_secrets_policy.arn
}

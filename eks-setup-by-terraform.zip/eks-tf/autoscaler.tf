# Reuse the cluster's OIDC issuer
locals {
  autoscaler_oidc_issuer_url  = aws_eks_cluster.main.identity[0].oidc[0].issuer
  autoscaler_oidc_issuer_host = trimprefix(local.autoscaler_oidc_issuer_url, "https://")

  autoscaler_irsa_conditions = {
    "${local.autoscaler_oidc_issuer_host}:sub" = "system:serviceaccount:kube-system:cluster-autoscaler"
    "${local.autoscaler_oidc_issuer_host}:aud" = "sts.amazonaws.com"
  }
}

resource "aws_iam_policy" "cluster_autoscaler" {
  name   = "AmazonEKSClusterAutoscalerPolicy"
  policy = file("${path.module}/cluster-autoscaler-policy.json")
}

resource "aws_iam_role" "cluster_autoscaler" {
  name = "eks-cluster-autoscaler-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Principal = {
        Federated = aws_iam_openid_connect_provider.eks.arn
      }
      Action = "sts:AssumeRoleWithWebIdentity"
      Condition = {
        StringEquals = local.autoscaler_irsa_conditions
      }
    }]
  })
}

resource "aws_iam_role_policy_attachment" "cluster_autoscaler_attach" {
  role       = aws_iam_role.cluster_autoscaler.name
  policy_arn = aws_iam_policy.cluster_autoscaler.arn
}

resource "kubernetes_service_account" "cluster_autoscaler" {
  metadata {
    name      = "cluster-autoscaler"
    namespace = "kube-system"
    annotations = {
      "eks.amazonaws.com/role-arn" = aws_iam_role.cluster_autoscaler.arn
    }
  }

  # Ensure cluster and IAM wiring exist before SA
  depends_on = [
    aws_eks_cluster.main,
    aws_eks_node_group.main,
    aws_iam_role_policy_attachment.cluster_autoscaler_attach
    # optionally: kubernetes_config_map.aws_auth or access entries if you manage them
  ]
}

# Split YAML manifests
locals {
  cluster_autoscaler_docs = [
    for doc in split("---", file("${path.module}/cluster-autoscaler.yml")) :
    trimspace(doc)
    if trimspace(doc) != ""
  ]
}

resource "kubectl_manifest" "cluster_autoscaler" {
  for_each  = { for idx, doc in local.cluster_autoscaler_docs : idx => doc }
  yaml_body = each.value

  # SA + IAM must exist before manifests (Deployment, RBAC, etc.)
  depends_on = [
    kubernetes_service_account.cluster_autoscaler,
    aws_iam_role_policy_attachment.cluster_autoscaler_attach
  ]
}

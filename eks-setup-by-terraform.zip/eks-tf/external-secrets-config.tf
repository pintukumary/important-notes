# SecretStore resource using kubectl_manifest
resource "kubectl_manifest" "secret_store" {
  yaml_body = <<YAML
apiVersion: external-secrets.io/v1beta1
kind: SecretStore
metadata:
  name: aws-secrets-manager
  namespace: default
spec:
  provider:
    aws:
      service: SecretsManager
      region: ${var.region}
      auth:
        serviceAccount:
          name: ${kubernetes_service_account.external_secrets.metadata[0].name}
YAML

  depends_on = [
    helm_release.external_secrets,
    kubernetes_service_account.external_secrets
  ]
}

# ExternalSecret resource to sync secrets from AWS Secrets Manager to Kubernetes
resource "kubectl_manifest" "external_secret" {
  yaml_body = <<YAML
apiVersion: external-secrets.io/v1beta1
kind: ExternalSecret
metadata:
  name: app-secrets
  namespace: default
spec:
  refreshInterval: 1m
  secretStoreRef:
    name: aws-secrets-manager
    kind: SecretStore
  target:
    name: app-secrets
    creationPolicy: Owner
    type: Opaque
  data:
    - secretKey: database-url
      remoteRef:
        key: ${aws_secretsmanager_secret.app_secrets.name}
        property: database_url
    - secretKey: database-username
      remoteRef:
        key: ${aws_secretsmanager_secret.app_secrets.name}
        property: database_username
    - secretKey: database-password
      remoteRef:
        key: ${aws_secretsmanager_secret.app_secrets.name}
        property: database_password
    - secretKey: api-key
      remoteRef:
        key: ${aws_secretsmanager_secret.app_secrets.name}
        property: api_key
    - secretKey: jwt-secret
      remoteRef:
        key: ${aws_secretsmanager_secret.app_secrets.name}
        property: jwt_secret
    - secretKey: redis-password
      remoteRef:
        key: ${aws_secretsmanager_secret.app_secrets.name}
        property: redis_password
    - secretKey: smtp-username
      remoteRef:
        key: ${aws_secretsmanager_secret.app_secrets.name}
        property: smtp_username
    - secretKey: smtp-password
      remoteRef:
        key: ${aws_secretsmanager_secret.app_secrets.name}
        property: smtp_password
    - secretKey: encryption-key
      remoteRef:
        key: ${aws_secretsmanager_secret.app_secrets.name}
        property: encryption_key
    - secretKey: oauth-client-id
      remoteRef:
        key: ${aws_secretsmanager_secret.app_secrets.name}
        property: oauth_client_id
    - secretKey: oauth-secret
      remoteRef:
        key: ${aws_secretsmanager_secret.app_secrets.name}
        property: oauth_secret
YAML

  depends_on = [
    kubectl_manifest.secret_store
  ]
}

Before setup eks cluster .
1. Install aws cli in your cli
2. install terraform cli
3. install helm version and run one time helm repo update to work properly.
4. instal eksctl and kubectl in local cli.

start terrafor with some Basic command.
1. terraform init
2. terraform validate
3. terraform plan
4. terraform apply
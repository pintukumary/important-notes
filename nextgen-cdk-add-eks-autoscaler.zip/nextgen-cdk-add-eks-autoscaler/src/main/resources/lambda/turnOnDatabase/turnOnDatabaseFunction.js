"use strict";
const {RDSClient, StartDBClusterCommand} = require("@aws-sdk/client-rds");

const client = new RDSClient({region: process.env.awsRegion});
const dbClusterIdentifier = process.env.dbClusterIdentifier;

exports.handler = async function (event, context) {
    console.log("starting the cluster...");
    const result = await client.send(new StartDBClusterCommand({
        DBClusterIdentifier: dbClusterIdentifier
    }));
    console.log(result);
};

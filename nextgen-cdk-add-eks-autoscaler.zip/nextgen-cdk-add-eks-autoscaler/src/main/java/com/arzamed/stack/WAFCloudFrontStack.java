package com.arzamed.stack;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.Getter;
import software.amazon.awscdk.CfnOutput;
import software.amazon.awscdk.Stack;
import software.amazon.awscdk.StackProps;
import software.amazon.awscdk.TagProps;
import software.amazon.awscdk.Tags;
import software.amazon.awscdk.services.wafv2.CfnWebACL;
import software.amazon.awscdk.services.wafv2.CfnWebACL.AllowActionProperty;
import software.amazon.awscdk.services.wafv2.CfnWebACL.BlockActionProperty;
import software.amazon.awscdk.services.wafv2.CfnWebACL.DefaultActionProperty;
import software.amazon.awscdk.services.wafv2.CfnWebACL.GeoMatchStatementProperty;
import software.amazon.awscdk.services.wafv2.CfnWebACL.ManagedRuleGroupStatementProperty;
import software.amazon.awscdk.services.wafv2.CfnWebACL.NotStatementProperty;
import software.amazon.awscdk.services.wafv2.CfnWebACL.OverrideActionProperty;
import software.amazon.awscdk.services.wafv2.CfnWebACL.RateBasedStatementProperty;
import software.amazon.awscdk.services.wafv2.CfnWebACL.RuleActionProperty;
import software.amazon.awscdk.services.wafv2.CfnWebACL.RuleProperty;
import software.amazon.awscdk.services.wafv2.CfnWebACL.StatementProperty;
import software.amazon.awscdk.services.wafv2.CfnWebACL.VisibilityConfigProperty;
import software.constructs.Construct;

public class WAFCloudFrontStack extends Stack {

    @Getter
    private String wafWebAclArn;

    public WAFCloudFrontStack(final Construct parent, final String name, StackProps pr) {

        super(parent, name, pr);

        createWafCloudFront();
    }

    private void createWafCloudFront() {
        Map<String, Integer> managedRules = new HashMap<>();

        managedRules.put("AWSManagedRulesCommonRuleSet", 10);
        managedRules.put("AWSManagedRulesAmazonIpReputationList", 20);
        managedRules.put("AWSManagedRulesKnownBadInputsRuleSet", 30);
        managedRules.put("AWSManagedRulesSQLiRuleSet", 40);
        managedRules.put("AWSManagedRulesLinuxRuleSet", 50);
        managedRules.put("AWSManagedRulesUnixRuleSet", 60);

        CfnWebACL cfnWebACL =
                CfnWebACL.Builder.create(this, "WafCloudFront")
                        .defaultAction(
                                DefaultActionProperty.builder()
                                        .allow(AllowActionProperty.builder().build())
                                        .build())
                        .scope("CLOUDFRONT")
                        .visibilityConfig(
                                VisibilityConfigProperty.builder()
                                        .cloudWatchMetricsEnabled(true)
                                        .metricName("waf-cloudfront")
                                        .sampledRequestsEnabled(true)
                                        .build())
                        .description("WAFv2 ACL for CloudFront")
                        .name("waf-cloudfront")
//            .rules(makeRules(managedRules))
                        .build();

        Tags.of(cfnWebACL).add("Name", "waf-cloudfront", TagProps.builder().priority(300).build());
        Tags.of(cfnWebACL).add("Purpose", "CloudFront", TagProps.builder().priority(300).build());
        Tags.of(cfnWebACL).add("CreatedBy", "CloudFormation", TagProps.builder().priority(300).build());

        CfnOutput.Builder.create(this, "wafAclCloudFrontArn")
                .description("WAF CloudFront arn")
                .value(cfnWebACL.getAttrArn())
                .exportName("WafCloudFrontStack:WafAclCloudFrontArn")
                .build();

        wafWebAclArn = cfnWebACL.getAttrArn();
    }

    protected List<RuleProperty> makeRules(Map<String, Integer> rules) {
        List<RuleProperty> ruleList = new ArrayList<>();

        for (Map.Entry<String, Integer> singleRule : rules.entrySet()) {
            String ruleName = singleRule.getKey();
            Integer rulePriority = singleRule.getValue();

            ruleList.add(
                    RuleProperty.builder()
                            .name(ruleName)
                            .priority(rulePriority)
                            .overrideAction(
                                    OverrideActionProperty.builder().none(new HashMap<String, Object>()).build())
                            .statement(
                                    StatementProperty.builder()
                                            .managedRuleGroupStatement(
                                                    ManagedRuleGroupStatementProperty.builder()
                                                            .name(ruleName)
                                                            .vendorName("AWS")
                                                            .build())
                                            .build())
                            .visibilityConfig(
                                    VisibilityConfigProperty.builder()
                                            .cloudWatchMetricsEnabled(true)
                                            .metricName(ruleName)
                                            .sampledRequestsEnabled(true)
                                            .build())
                            .build());
        }

        ruleList.add(
                RuleProperty.builder()
                        .name("GeoMatch")
                        .priority(0)
                        .action(
                                RuleActionProperty.builder().block(BlockActionProperty.builder().build()).build())
                        .statement(
                                StatementProperty.builder()
                                        .notStatement(
                                                NotStatementProperty.builder()
                                                        .statement(
                                                                StatementProperty.builder()
                                                                        .geoMatchStatement(
                                                                                GeoMatchStatementProperty.builder()
                                                                                        .countryCodes(
                                                                                                List.of(
                                                                                                        "AR", // Argentina
                                                                                                        "BO", // Bolivia
                                                                                                        "BR", // Brazil
                                                                                                        "CL", // Chile
                                                                                                        "CO", // Colombia
                                                                                                        "EC", // Ecuador
                                                                                                        "FK", // Falkland Islands
                                                                                                        "GF", // French Guiana
                                                                                                        "GY", // Guiana
                                                                                                        "GY", // Guyana
                                                                                                        "PY", // Paraguay
                                                                                                        "PE", // Peru
                                                                                                        "SR", // Suriname
                                                                                                        "UY", // Uruguay
                                                                                                        "VE")) // Venezuela
                                                                                        .build())
                                                                        .build())
                                                        .build())
                                        .build())
                        .visibilityConfig(
                                VisibilityConfigProperty.builder()
                                        .cloudWatchMetricsEnabled(true)
                                        .metricName("GeoMatch")
                                        .sampledRequestsEnabled(true)
                                        .build())
                        .build());

        ruleList.add(
                RuleProperty.builder()
                        .name("LimitRequests100")
                        .priority(1)
                        .action(
                                RuleActionProperty.builder().block(BlockActionProperty.builder().build()).build())
                        .statement(
                                StatementProperty.builder()
                                        .rateBasedStatement(
                                                RateBasedStatementProperty.builder()
                                                        .aggregateKeyType("IP")
                                                        .limit(100)
                                                        .build())
                                        .build())
                        .visibilityConfig(
                                VisibilityConfigProperty.builder()
                                        .cloudWatchMetricsEnabled(true)
                                        .metricName("LimitRequests100")
                                        .sampledRequestsEnabled(true)
                                        .build())
                        .build());
        return ruleList;
    }
}

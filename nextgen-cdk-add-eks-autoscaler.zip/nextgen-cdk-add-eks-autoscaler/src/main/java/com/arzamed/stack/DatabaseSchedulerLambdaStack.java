package com.arzamed.stack;

import com.arzamed.config.ApplicationConfiguration;
import org.jetbrains.annotations.Nullable;
import software.amazon.awscdk.Fn;
import software.amazon.awscdk.Stack;
import software.amazon.awscdk.StackProps;
import software.amazon.awscdk.services.events.CronOptions;
import software.amazon.awscdk.services.events.Rule;
import software.amazon.awscdk.services.events.RuleProps;
import software.amazon.awscdk.services.events.Schedule;
import software.amazon.awscdk.services.events.targets.LambdaFunction;
import software.amazon.awscdk.services.iam.*;
import software.amazon.awscdk.services.lambda.Code;
import software.amazon.awscdk.services.lambda.Function;
import software.amazon.awscdk.services.lambda.FunctionProps;
import software.amazon.awscdk.services.lambda.Runtime;
import software.constructs.Construct;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

public class DatabaseSchedulerLambdaStack extends Stack {
    public DatabaseSchedulerLambdaStack(@Nullable Construct scope, @Nullable String id, @Nullable StackProps props,
                                        ApplicationConfiguration applicationConfiguration) {
        super(scope, id, props);

        String dbClusterIdentifier = Fn.importValue("AuroraPostgresStack:DatabaseClusterIdentifier");

        Rule turnOnDatabaseRule = new Rule(this, "TurnOnDatabaseRule",
                RuleProps.builder()
                        .schedule(Schedule.cron(CronOptions.builder()
                                .minute("55")
                                .hour("4")
                                .weekDay("MON-FRI")
                                .build()))
                        .build());

        Function turnOnFunction = new Function(this, "TurnOnDatabaseFunction", FunctionProps.builder()
                .runtime(Runtime.NODEJS_20_X)
                .handler("turnOnDatabaseFunction.handler")
                .environment(new HashMap<>() {{
                    put("dbClusterIdentifier", dbClusterIdentifier);
                    put("awsRegion", applicationConfiguration.getRegion());
                }})
                .code(Code.fromAsset("./src/main/resources/lambda/turnOnDatabase"))
                .build());

        turnOnFunction.addToRolePolicy(new PolicyStatement(PolicyStatementProps.builder()
                .effect(Effect.ALLOW)
                .actions(List.of(
                        "rds:StartDbCluster",
                        "rds:StopDbCluster"
                ))
                .resources(Collections.singletonList(
                        String.format("arn:aws:rds:%s:%s:cluster:*", applicationConfiguration.getRegion(),
                                applicationConfiguration.getDefaultAccount())))
                .build()));

        turnOnDatabaseRule.addTarget(new LambdaFunction(turnOnFunction));

        Rule turnOffDatabaseRule = new Rule(this, "TurnOffDatabaseRule",
                RuleProps.builder()
                        .schedule(Schedule.cron(CronOptions.builder()
                                .minute("0")
                                .hour("16")
                                .weekDay("MON-FRI")
                                .build()))
                        .build());

        Function turnOffFunction = new Function(this, "TurnOffDatabaseFunction", FunctionProps.builder()
                .runtime(Runtime.NODEJS_20_X)
                .handler("turnOffDatabaseFunction.handler")
                .environment(new HashMap<>() {{
                    put("dbClusterIdentifier", dbClusterIdentifier);
                    put("awsRegion", applicationConfiguration.getRegion());
                }})
                .code(Code.fromAsset("./src/main/resources/lambda/turnOffDatabase"))
                .build());

        turnOffFunction.addToRolePolicy(new PolicyStatement(PolicyStatementProps.builder()
                .effect(Effect.ALLOW)
                .actions(List.of(
                        "rds:StartDbCluster",
                        "rds:StopDbCluster"
                ))
                .resources(Collections.singletonList(
                        String.format("arn:aws:rds:%s:%s:cluster:*", applicationConfiguration.getRegion(),
                                applicationConfiguration.getDefaultAccount())))
                .build()));

        turnOffDatabaseRule.addTarget(new LambdaFunction(turnOffFunction));
    }
}

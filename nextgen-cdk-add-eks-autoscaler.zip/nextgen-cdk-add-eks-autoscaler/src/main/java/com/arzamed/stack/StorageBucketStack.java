package com.arzamed.stack;

import java.util.Collections;
import java.util.List;

import com.arzamed.config.ApplicationConfiguration;
import com.arzamed.config.StorageBucketConfiguration;

import software.amazon.awscdk.RemovalPolicy;
import software.amazon.awscdk.Stack;
import software.amazon.awscdk.services.iam.*;
import software.amazon.awscdk.services.s3.BlockPublicAccess;
import software.amazon.awscdk.services.s3.BlockPublicAccessOptions;
import software.amazon.awscdk.services.s3.Bucket;
import software.constructs.Construct;

/**
 * Storage bucket infrastructure, which creates a S3 bucket for storage.
 */
public class StorageBucketStack extends Stack {

    public static final String S3_FULL_ACCESS = "arn:aws:iam::aws:policy/AmazonS3FullAccess";

    public StorageBucketStack(Construct scope, String id, ApplicationConfiguration configuration) {
        super(scope, id);

        Role role = createBucketRole(id);
        createStorageBucket(configuration.getStorageBucketConfiguration(), role);
    }

    private void createStorageBucket(StorageBucketConfiguration bucketConfig, Role role) {
        Bucket storageBucket = Bucket.Builder.create(this, "StorageBucket")
                .bucketName(bucketConfig.getBucketName())
                .removalPolicy(RemovalPolicy.valueOf(bucketConfig.getRemovalPolicy()))
                .blockPublicAccess(new BlockPublicAccess(BlockPublicAccessOptions.builder()
                        .blockPublicPolicy(false)
                        .build()))
                .build();

        storageBucket.grantReadWrite(role);

        if (bucketConfig.isPublicAccessAllowed()) {
            storageBucket.addToResourcePolicy(
                    PolicyStatement.Builder.create()
                            .sid("AllowPublicRead")
                            .effect(Effect.ALLOW)
                            .resources(List.of(storageBucket.getBucketArn() + "/*"))
                            .actions(List.of(bucketConfig.getActions()))
                            .principals(List.of(role))
                            .build());

            storageBucket.addToResourcePolicy(PolicyStatement.Builder.create()
                    .sid("AllowPublicReadToAnyone")
                    .effect(Effect.ALLOW)
                    .resources(List.of(storageBucket.getBucketArn() + "/*"))
                    .actions(List.of("s3:GetObject"))
                    .principals(List.of(new AnyPrincipal()))
                    .build());
        }
    }

    private Role createBucketRole(String id) {
        return Role.Builder.create(this, id + "-role")
                .assumedBy(ServicePrincipal.Builder.create("cloudformation.amazonaws.com").build())
                .managedPolicies(Collections.singletonList(
                        ManagedPolicy.fromManagedPolicyArn(this, id + "-managed-policy", S3_FULL_ACCESS)))
                .roleName(id + "-role")
                .build();
    }
}

package com.arzamed.stack;

import java.util.List;
import java.util.Map;

import com.arzamed.config.ApplicationConfiguration;
import com.arzamed.config.BastionConfiguration;
import com.arzamed.config.EksPrivateClusterConfiguration;
import com.arzamed.config.IngressRuleConfiguration;
import com.arzamed.config.SecurityGroupConfiguration;
import com.arzamed.config.SubnetConfig;
import com.arzamed.config.VpcConfiguration;

import lombok.Getter;
import software.amazon.awscdk.CfnOutput;
import software.amazon.awscdk.Stack;
import software.amazon.awscdk.StackProps;
import software.amazon.awscdk.cdk.lambdalayer.kubectl.v32.KubectlV32Layer;
import software.amazon.awscdk.services.ec2.BastionHostLinux;
import software.amazon.awscdk.services.ec2.BlockDevice;
import software.amazon.awscdk.services.ec2.BlockDeviceVolume;
import software.amazon.awscdk.services.ec2.CfnEIP;
import software.amazon.awscdk.services.ec2.CfnEIPAssociation;
import software.amazon.awscdk.services.ec2.CfnNatGateway;
import software.amazon.awscdk.services.ec2.CfnRoute;
import software.amazon.awscdk.services.ec2.EbsDeviceOptions;
import software.amazon.awscdk.services.ec2.GatewayVpcEndpointAwsService;
import software.amazon.awscdk.services.ec2.GatewayVpcEndpointOptions;
import software.amazon.awscdk.services.ec2.ISubnet;
import software.amazon.awscdk.services.ec2.InstanceClass;
import software.amazon.awscdk.services.ec2.InstanceSize;
import software.amazon.awscdk.services.ec2.InstanceType;
import software.amazon.awscdk.services.ec2.InterfaceVpcEndpointAwsService;
import software.amazon.awscdk.services.ec2.InterfaceVpcEndpointOptions;
import software.amazon.awscdk.services.ec2.IpAddresses;
import software.amazon.awscdk.services.ec2.MachineImage;
import software.amazon.awscdk.services.ec2.OperatingSystemType;
import software.amazon.awscdk.services.ec2.Peer;
import software.amazon.awscdk.services.ec2.Port;
import software.amazon.awscdk.services.ec2.SecurityGroup;
import software.amazon.awscdk.services.ec2.SsmParameterImageOptions;
import software.amazon.awscdk.services.ec2.SubnetConfiguration;
import software.amazon.awscdk.services.ec2.SubnetSelection;
import software.amazon.awscdk.services.ec2.SubnetType;
import software.amazon.awscdk.services.ec2.UserData;
import software.amazon.awscdk.services.ec2.Vpc;
import software.amazon.awscdk.services.eks.*;
import software.amazon.awscdk.services.iam.*;

import software.constructs.Construct;

/**
 * Builds a private EKS cluster in isolated subnets with no Internet or NAT gateways attached.
 */
public class EksPrivateClusterStack extends Stack {

    @Getter
    private Vpc vpc;
    @Getter
    private Cluster cluster;

    public EksPrivateClusterStack(final Construct scope, final String id, final StackProps props,
                                  ApplicationConfiguration configuration) {
        super(scope, id, props);

        var eksPrivateClusterConfig = configuration.getEksPrivateCluster();

        createVpc(eksPrivateClusterConfig.getVpcConfiguration());

        var publicSubnetId = vpc.getPublicSubnets().get(0).getSubnetId();
        createNatGateway("CustomNatGateway", publicSubnetId);

        // addEndpoints();

        Role clusterAdmin = createClusterAdminRole(eksPrivateClusterConfig);

        createEksCluster(clusterAdmin, eksPrivateClusterConfig);
        addNodes(eksPrivateClusterConfig);

        createBastion(clusterAdmin, eksPrivateClusterConfig.getBastionConfiguration());

        // Instantiate SecretsManagerStack
        String profile = (String) this.getNode().tryGetContext("profile");
        if (profile == null) {
            profile = "uat"; // Default to uat
        }
        new SecretsManagerStack(this, "SecretsManagerStack", cluster, configuration.getRegion(), profile);
    }

    private Role createClusterAdminRole(EksPrivateClusterConfiguration eksPrivateClusterConfig) {
        return Role.Builder.create(this, eksPrivateClusterConfig.getAdminRoleName())
                .assumedBy(new AccountRootPrincipal())
                .inlinePolicies(Map.of("eksPolicy", PolicyDocument.Builder.create()
                        .statements(List.of(PolicyStatement.Builder.create()
                                .effect(Effect.ALLOW)
                                .actions(List.of("eks:*"))
                                .resources(List.of("*"))
                                .build()))
                        .build()))
                .build();
    }

    /**
     * Create a VPC with only isolated subnets and no public or private with egress.
     */
    private void createVpc(VpcConfiguration vpcConfig) {
        vpc = Vpc.Builder.create(this, "vpc")
                .ipAddresses(IpAddresses.cidr(vpcConfig.getCidrBlock()))
                .maxAzs(vpcConfig.getMaxAzs())
                .natGateways(vpcConfig.getNatGateways())
                .vpcName(vpcConfig.getVpcName())
                .subnetConfiguration(createSubnetConfigurations(vpcConfig.getSubnets()))
                .build();
    }

    private CfnEIP createCfnEip(String id, String domain) {
        return CfnEIP.Builder
                .create(this, id)
                .domain(domain)
                .build();
    }

    private void createNatGateway(String natGateWayId, String subnetId) {
        CfnEIP customEip = createCfnEip("CustomEip", "nat-domain");

        var customNatGateway = CfnNatGateway.Builder.create(this, natGateWayId)
                .allocationId(customEip.getAttrAllocationId())
                .subnetId(subnetId)
                .build();

        int i = 0;
        for (ISubnet pvtSubnet : vpc.getIsolatedSubnets()) {
            buildCfnRoute("PvtSubnetNatGatewayRoute" + i++,
                    customNatGateway.getRef(), pvtSubnet.getRouteTable().getRouteTableId());
        }
    }

    private void buildCfnRoute(String id, String natGatewayId, String routeTableID) {
        CfnRoute.Builder.create(this, id)
                .destinationCidrBlock("0.0.0.0/0")
                .natGatewayId(natGatewayId)
                .routeTableId(routeTableID)
                .build();
    }

    private void createEksCluster(Role clusterAdmin, EksPrivateClusterConfiguration eksPrivateClusterConfig) {
        cluster = Cluster.Builder.create(this, "eks")
                .vpc(vpc)
                .version(KubernetesVersion.of(eksPrivateClusterConfig.getKubernetesVersion()))
                .vpcSubnets(List.of(SubnetSelection.builder().subnetType(SubnetType.PRIVATE_ISOLATED).build()))
                .endpointAccess(EndpointAccess.PRIVATE)
                .clusterName(eksPrivateClusterConfig.getClusterName())
                .kubectlLayer(new KubectlV32Layer(this, eksPrivateClusterConfig.getKubectlLayerName()))
                .defaultCapacity(0)
                .mastersRole(clusterAdmin)
                .placeClusterHandlerInVpc(true)
                .clusterHandlerEnvironment(Map.of("AWS_STS_REGIONAL_ENDPOINTS", "regional"))
                .kubectlEnvironment(Map.of("AWS_STS_REGIONAL_ENDPOINTS", "regional"))
                .outputClusterName(true)
                .outputConfigCommand(true)
                .outputMastersRoleArn(true)
                .build();

        if (cluster.getNode().getDefaultChild() instanceof CfnCluster cfnCluster) {
            cfnCluster.setAccessConfig(CfnCluster.AccessConfigProperty.builder()
                    .authenticationMode("API_AND_CONFIG_MAP")
                    .build());
        }

        int i = 1;
        for (ISubnet subnet : cluster.getVpc().getPublicSubnets()) {
            CfnOutput.Builder.create(this, "PublicSubnetOutput" + i)
                    .key("PublicSubnet" + i + "Id")
                    .value(subnet.getSubnetId())
                    .build();
            i++;
        }

        if (eksPrivateClusterConfig.isEnableClusterAutoscaler()) {
            new ClusterAutoscalerConstruct(this, "ClusterAutoscaler",
                    cluster,  // Your EKS Cluster object
                    eksPrivateClusterConfig.getClusterName(),
                    eksPrivateClusterConfig.getAutoscalerImage()
            );
        }
        new FluentBitConstruct(this, "FluentBit", cluster, eksPrivateClusterConfig.getRegion());

        //Creating an ALB controller to enable creating Ingresses backed by ALB, without launching scripts to install it
        //WARNING: seems it needs the cluster to have at least 1 instance, or it won't install
        new AlbController(this, "alb-controller",
                AlbControllerProps.builder()
                        .cluster(cluster)
                        .version(AlbControllerVersion.V2_8_2)
                        .build());

        HelmChart.Builder.create(this, "MetricsServer")
                .cluster(cluster)
                .chart("metrics-server")
                .repository("https://kubernetes-sigs.github.io/metrics-server/")
                .namespace("kube-system")
                .release("metrics-server")
                .version("3.12.2")
                .build();

        HelmChart.Builder.create(this,"KubeStateMetrics")
                .cluster(cluster)
                .chart("kube-state-metrics")
                .repository("https://prometheus-community.github.io/helm-charts")
                .namespace("kube-system")
                .release("kube-state-metrics")
                .version("6.1.0")
                .build();
    }

    private void addNodes(EksPrivateClusterConfiguration eksPrivateClusterConfig) {
        var instanceTypeConfig = eksPrivateClusterConfig.getInstanceTypeConfig();
        InstanceType instanceType = InstanceType.of(
                InstanceClass.valueOf(instanceTypeConfig.getInstanceClass()),
                InstanceSize.valueOf(instanceTypeConfig.getInstanceSize()));

        //add a managed node group
        Nodegroup managedNodeGroup = cluster.addNodegroupCapacity("uat-managed-node-group", NodegroupOptions.builder()
                .instanceTypes(List.of(instanceType))
                .amiType(NodegroupAmiType.AL2023_X86_64_STANDARD)
                .subnets(SubnetSelection.builder().subnetType(SubnetType.PRIVATE_ISOLATED).build())
                .minSize(2)
                .desiredSize(2)
                .maxSize(6)
                .build());

        managedNodeGroup.getRole()
                .addManagedPolicy(ManagedPolicy.fromAwsManagedPolicyName("AmazonSSMManagedInstanceCore"));
    }

    private SecurityGroup createBastionSecurityGroup(SecurityGroupConfiguration securityGroupConfig) {
        SecurityGroup bastionSg = SecurityGroup.Builder.create(this, "BastionSG")
                .securityGroupName(securityGroupConfig.getName())
                .allowAllOutbound(securityGroupConfig.isAllowAllOutbound())
                .vpc(vpc)
                .build();

        IngressRuleConfiguration ingressRule = securityGroupConfig.getIngressRule();

        bastionSg.addIngressRule(
                Peer.ipv4(ingressRule.getCidr()),
                Port.tcp(ingressRule.getPort()),
                ingressRule.getDescription());

        cluster.getClusterSecurityGroup().addIngressRule(
                Peer.securityGroupId(bastionSg.getSecurityGroupId()),
                Port.allTraffic());

        return bastionSg;
    }

    /**
     * Create an EC2 instance in one of the isolated subnet accessible via SSM for kubectl.
     *
     * @param clusterAdmin  - cluster admin role
     * @param bastionConfig - bastion configuration
     */
    private void createBastion(Role clusterAdmin, BastionConfiguration bastionConfig) {

        SecurityGroup bastionSG = createBastionSecurityGroup(bastionConfig.getSecurityGroupConfig());

        var instanceTypeConfig = bastionConfig.getInstanceTypeConfig();
        InstanceType instanceType = InstanceType.of(
                InstanceClass.valueOf(instanceTypeConfig.getInstanceClass()),
                InstanceSize.valueOf(instanceTypeConfig.getInstanceSize()));

        BastionHostLinux client = BastionHostLinux.Builder
                .create(this, bastionConfig.getInstanceName())
                .vpc(vpc)
                .instanceName(bastionConfig.getInstanceName())
                .machineImage(
                        MachineImage.fromSsmParameter(
                                bastionConfig.getMachineImageSsm(),
                                SsmParameterImageOptions.builder()
                                        .os(OperatingSystemType.valueOf(bastionConfig.getOs()))
                                        .userData(UserData.custom(bastionConfig.getUserData()))
                                        .cachedInContext(true)
                                        .build()
                        ))
                .blockDevices(
                        List.of(
                                BlockDevice.builder()
                                        .deviceName(bastionConfig.getDeviceName())
                                        .volume(
                                                BlockDeviceVolume.ebs(
                                                        30, EbsDeviceOptions.builder().encrypted(true).build()))
                                        .build()))
                .subnetSelection(SubnetSelection.builder().subnetType(SubnetType.PUBLIC).build())
                .securityGroup(bastionSG)
                .instanceType(instanceType)
                .build();

        // client.getInstance().getInstance().addPropertyOverride("KeyName", bastionConfig.getKeyName());

        clusterAdmin.grantAssumeRole(client.getRole());

        client.getInstance()
                .addToRolePolicy(
                        PolicyStatement.Builder.create()
                                .effect(Effect.ALLOW)
                                .actions(List.of("eks:DescribeCluster", "eks:ListClusters"))
                                .resources(List.of("*"))
                                .build());

        client.getRole().addManagedPolicy(ManagedPolicy.fromAwsManagedPolicyName("AmazonEC2ContainerRegistryReadOnly"));
        client.getRole().addManagedPolicy(ManagedPolicy.fromAwsManagedPolicyName("AmazonS3ReadOnlyAccess"));

        CfnEIP customEip = createCfnEip("CustomEipBastion", "bastion-domain");
        CfnEIPAssociation.Builder.create(this, "bastionEip")
                .allocationId(customEip.getAttrAllocationId())
                .instanceId(client.getInstanceId())
                .build();

        CfnOutput.Builder.create(this, "cfnBastionEip")
                .key("bastionEip")
                .value(customEip.getAttrPublicIp())
                .build();
    }

    private void addEndpoints() {
        List<InterfaceVpcEndpointAwsService> endpoints =
                List.of(
                        InterfaceVpcEndpointAwsService.ECR,
                        InterfaceVpcEndpointAwsService.ECR_DOCKER,
                        InterfaceVpcEndpointAwsService.CLOUDWATCH_MONITORING,
                        InterfaceVpcEndpointAwsService.CLOUDWATCH_LOGS,
                        InterfaceVpcEndpointAwsService.STS,
                        InterfaceVpcEndpointAwsService.SSM,
                        InterfaceVpcEndpointAwsService.SSM_MESSAGES,
                        InterfaceVpcEndpointAwsService.LAMBDA,
                        InterfaceVpcEndpointAwsService.EKS,
                        InterfaceVpcEndpointAwsService.EC2,
                        InterfaceVpcEndpointAwsService.EC2_MESSAGES,
                        InterfaceVpcEndpointAwsService.STEP_FUNCTIONS,
                        InterfaceVpcEndpointAwsService.STEP_FUNCTIONS_SYNC);

        SubnetSelection subnets =
                SubnetSelection.builder().subnetType(SubnetType.PRIVATE_ISOLATED).build();

        for (InterfaceVpcEndpointAwsService e : endpoints) {
            vpc.addInterfaceEndpoint(
                    e.getShortName(), InterfaceVpcEndpointOptions.builder().service(e).subnets(subnets).build());
        }

        vpc.addGatewayEndpoint(
                "s3", GatewayVpcEndpointOptions.builder().service(GatewayVpcEndpointAwsService.S3).build());
    }

    private List<SubnetConfiguration> createSubnetConfigurations(List<SubnetConfig> subnetConfigs) {
        return subnetConfigs.stream()
                .map(subnetConfig -> SubnetConfiguration.builder()
                        .cidrMask(subnetConfig.getCidrMask())
                        .name(subnetConfig.getName())
                        .subnetType(SubnetType.valueOf(subnetConfig.getSubnetType()))
                        .build())
                .toList();
    }
}

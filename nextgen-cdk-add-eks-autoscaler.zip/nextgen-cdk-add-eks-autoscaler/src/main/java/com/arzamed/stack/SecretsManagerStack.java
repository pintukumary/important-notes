package com.arzamed.stack;

import software.amazon.awscdk.RemovalPolicy;
import software.amazon.awscdk.SecretValue;
import software.amazon.awscdk.Stack;
import software.amazon.awscdk.services.eks.Cluster;
import software.amazon.awscdk.services.eks.HelmChart;
import software.amazon.awscdk.services.eks.HelmChartOptions;
import software.amazon.awscdk.services.eks.ServiceAccount;
import software.amazon.awscdk.services.eks.ServiceAccountOptions;
import software.amazon.awscdk.services.secretsmanager.Secret;
import software.amazon.awscdk.services.iam.Effect;
import software.amazon.awscdk.services.iam.PolicyStatement;
import software.constructs.Construct;

import java.util.Map;
import java.util.List;

public class SecretsManagerStack extends Construct {

    public SecretsManagerStack(final Construct scope, final String id, final Cluster cluster, final String region, final String profile) {
        super(scope, id);

        // Validate stack scope
        Stack stack = Stack.of(scope);
        if (stack == null) {
            throw new IllegalArgumentException("SecretsManagerStack must be created within a Stack scope");
        }

        // Determine environment-specific values
        String env = profile != null && profile.equals("prod") ? "prod" : "uat";
        String clusterName = "eks-private-" + env;
        String namespace = "arzamed-plus365-" + env;
        String secretName = "/eks/" + clusterName + "/" + namespace + "/app-secret";

        // Create a Secrets Manager secret
        Secret secret = Secret.Builder.create(this, "AppSecret")
                .secretName(secretName)
                .description("Secret for arzamed-plus365-" + env + " application credentials")
                .secretObjectValue(Map.<String, SecretValue>of(
                        "api-key", SecretValue.unsafePlainText("asdsesed"),
                        "db-password", SecretValue.unsafePlainText("Admin@123"),
                        "PRODUCTION", SecretValue.unsafePlainText("example-production-" + env),
                        "MONGO_CON", SecretValue.unsafePlainText("example-mongo-con-" + env)
                ))
                .removalPolicy(RemovalPolicy.DESTROY)
                .build();

        // Create a service account for ESO
        ServiceAccount esoServiceAccount = cluster.addServiceAccount("ESOServiceAccount", ServiceAccountOptions.builder()
                .name("eks-aws-secrets-sa")
                .namespace(namespace)
                .build());

        // Grant IRSA permissions to access the secret
        esoServiceAccount.addToPrincipalPolicy(PolicyStatement.Builder.create()
                .effect(Effect.ALLOW)
                .actions(List.of(
                        "secretsmanager:GetSecretValue",
                        "secretsmanager:DescribeSecret"
                ))
                .resources(List.of(secret.getSecretArn()))
                .build());

        // Install External Secrets Operator via Helm
        HelmChart esoHelmChart = cluster.addHelmChart("ExternalSecretsOperator", HelmChartOptions.builder()
                .chart("external-secrets")
                .repository("https://charts.external-secrets.io")
                .namespace("kube-system")
                .release("external-secrets")
                .version("0.10.4") // Stable version; update as needed
                .values(Map.<String, Object>of(
                        "installCRDs", true // Ensures CRDs for SecretStore and ExternalSecret are installed
                ))
                .build());
    }
}

package com.arzamed.stack;

import com.arzamed.config.ApplicationConfiguration;

import software.amazon.awscdk.CfnOutput;
import software.amazon.awscdk.RemovalPolicy;
import software.amazon.awscdk.Stack;
import software.amazon.awscdk.StackProps;
import software.amazon.awscdk.services.ecr.Repository;
import software.constructs.Construct;

public class EcrStack extends Stack {

    public EcrStack(final Construct scope, final String id, final StackProps stackProps,
                    ApplicationConfiguration configuration) {
        super(scope, id, stackProps);

        createRepositories(configuration.getRepositoryNames());
    }

    private void createRepositories(String[] repositoryNames) {
        for (String repoName : repositoryNames) {
            Repository repository = Repository.Builder.create(this, "repo-" + repoName)
                    .repositoryName(repoName)
                    .removalPolicy(RemovalPolicy.DESTROY)
                    .build();

            CfnOutput.Builder.create(this, "cfn-repo-" + repoName)
                    .key(repoName.replaceAll("[^A-Za-z0-9]", "") + "RepoUrl")
                    .value(repository.getRepositoryUri())
                    .build();
        }
    }

}

package com.arzamed.stack;

import java.util.List;
import java.util.Map;

import com.arzamed.config.ApplicationConfiguration;
import com.arzamed.config.SESConfiguration;

import software.amazon.awscdk.Stack;
import software.amazon.awscdk.StackProps;
import software.amazon.awscdk.services.iam.Effect;
import software.amazon.awscdk.services.iam.Policy;
import software.amazon.awscdk.services.iam.PolicyStatement;
import software.amazon.awscdk.services.pinpointemail.CfnIdentity;
import software.constructs.Construct;

public class SESStack extends Stack {

    public SESStack(final Construct scope, final String id, final StackProps stackProps,
                    ApplicationConfiguration configuration) {
        super(scope, id, stackProps);

        createSESPolicies(configuration.getSesConfiguration());
    }

    private void createSESPolicies(SESConfiguration sesConfig) {
        CfnIdentity.Builder.create(this, "Identity")
                .name(sesConfig.getSenderEmail())
                .build();

        var policyStatement = PolicyStatement.Builder.create()
                .effect(Effect.ALLOW)
                .actions(List.of("ses:SendEmail", "ses:SendRawEmail"))
                .resources(List.of("*"))
                .conditions(Map.of("StringEquals", Map.of("ses:FromAddress", sesConfig.getVerifiedEmail())))
                .build();

        var policy = Policy.Builder.create(this, "IdentityPolicy")
                .statements(List.of(policyStatement))
                .build();

        policy.addStatements(policyStatement);
    }

}

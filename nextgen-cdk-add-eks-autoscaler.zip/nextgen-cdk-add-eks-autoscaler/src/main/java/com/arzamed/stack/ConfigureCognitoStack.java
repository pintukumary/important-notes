package com.arzamed.stack;

import java.util.Collections;
import java.util.Map;

import org.jetbrains.annotations.NotNull;

import com.arzamed.config.ApplicationConfiguration;

import software.amazon.awscdk.CfnParameter;
import software.amazon.awscdk.Duration;
import software.amazon.awscdk.RemovalPolicy;
import software.amazon.awscdk.Stack;
import software.amazon.awscdk.StackProps;
import software.amazon.awscdk.services.cognito.*;
import software.amazon.awscdk.services.iam.IManagedPolicy;
import software.amazon.awscdk.services.iam.ManagedPolicy;
import software.amazon.awscdk.services.iam.Role;
import software.amazon.awscdk.services.iam.ServicePrincipal;
import software.amazon.awscdk.services.iam.WebIdentityPrincipal;
import software.constructs.Construct;

/**
 * ConfigureCognito infrastructure stack
 */
public class ConfigureCognitoStack extends Stack {

    IManagedPolicy awsOpenSearchCognitoAccessPolicy = ManagedPolicy.fromAwsManagedPolicyName(
            "AmazonOpenSearchServiceCognitoAccess");
    private CfnParameter userEmail;
    private CfnParameter cognitoDomainName;

    public ConfigureCognitoStack(final Construct scope, final String id,
                                 final StackProps props, ApplicationConfiguration configuration) {
        super(scope, id, props);

        createParameters(configuration);

        configureCognito(configuration);
    }

    private void configureCognito(ApplicationConfiguration configuration) {
        //Create cognito user pool
        UserPool userPool = createUserPool();

        //Set Cognito Domain
        userPool.addDomain("Arzamed-Cognito-Domain", UserPoolDomainProps.builder()
                .userPool(userPool)
                .cognitoDomain(CognitoDomainOptions.builder()
                        .domainPrefix(cognitoDomainName.getValueAsString())
                        .build())
                .managedLoginVersion(ManagedLoginVersion.NEWER_MANAGED_LOGIN)
                .build());

        //Create Identity pool
        CfnIdentityPool identityPool = CfnIdentityPool.Builder.create(this, "CognitoIdentityPool")
                .allowUnauthenticatedIdentities(false)
                .build();

        //Build Identity Pool role
        Role authenticatedUserRole = Role.Builder.create(this, "CognitoAuthenticatedIdentityPoolRole")
                .assumedBy(
                        new WebIdentityPrincipal("cognito-identity.amazonaws.com",
                                Map.of(
                                        "StringEquals", Map.of("cognito-identity.amazonaws.com:aud", identityPool.getRef()),
                                        "ForAnyValue:StringLike", Map.of("cognito-identity.amazonaws.com:amr", "authenticated"))
                        ))
                .managedPolicies(Collections.singletonList(awsOpenSearchCognitoAccessPolicy))
                .build();

        //Attach role to IP
        CfnIdentityPoolRoleAttachment.Builder.create(this, "IdentityPoolRoleAttachment")
                .identityPoolId(identityPool.getRef())
                .roles(Map.of("authenticated", authenticatedUserRole.getRoleArn()))
                .build();

        //Create admin user with a password passed as a parameter to the stack
        createAdminUser(configuration, userPool);

        //Lastly attach a role to authenticated users
        Role.Builder.create(this, "CognitoAuthenticatedUserRole")
                .description("Role attached to Cognito authenticated users")
                .maxSessionDuration(Duration.hours(2))
                .managedPolicies(Collections.singletonList(awsOpenSearchCognitoAccessPolicy))
                .assumedBy(ServicePrincipal.Builder.create("es.amazonaws.com").build())
                .build();
    }

    private void createAdminUser(ApplicationConfiguration configuration, UserPool userPool) {
        CfnUserPoolUser.Builder.create(this, "AdminUser")
                .userPoolId(userPool.getUserPoolId())
                .forceAliasCreation(true)
                .username(configuration.getAdminEmail())  // Assuming admin email is used as username
                .desiredDeliveryMediums(Collections.singletonList("EMAIL"))
                .userAttributes(Collections.singletonList(CfnUserPoolUser.AttributeTypeProperty.builder()
                        .name("email")
                        .value(userEmail.getValueAsString()).build()))
                .build();
    }

    @NotNull
    private UserPool createUserPool() {
        return UserPool.Builder.create(this, "UserPool")
                .accountRecovery(AccountRecovery.EMAIL_ONLY)
                .standardAttributes(StandardAttributes.builder()
                        .email(StandardAttribute.builder()
                                .required(true)
                                .build())
                        .build())
                .passwordPolicy(PasswordPolicy.builder()
                        .minLength(8)
                        .build())
                .userVerification(UserVerificationConfig.builder()
                        .build())
                .autoVerify(AutoVerifiedAttrs.builder()
                        .email(true)
                        .build())
                .removalPolicy(RemovalPolicy.DESTROY)
                .build();
    }

    private void createParameters(ApplicationConfiguration configuration) {
        this.userEmail = CfnParameter.Builder.create(this, "DashboardsAdminEmail")
                .type("String")
                .defaultValue(configuration.getAdminEmail())
                .description("user e-mail address")
                .build();
        this.cognitoDomainName = CfnParameter.Builder.create(this, "CognitoDomain")
                .type("String")
                .defaultValue(configuration.getCognitoDomain())
                .description("Name for Cognito Domain")
                .build();
    }
}

package com.arzamed.stack;

import software.amazon.awscdk.services.eks.ServiceAccount;
import software.amazon.awscdk.services.eks.ServiceAccountOptions;
import software.amazon.awscdk.services.eks.Cluster;
import software.amazon.awscdk.services.iam.*;
import software.constructs.Construct;

import java.util.List;
import java.util.Map;

public class ClusterAutoscalerConstruct extends Construct {

    public ClusterAutoscalerConstruct(final Construct scope, final String id, final Cluster cluster,
                                      final String clusterName, final String autoscalerImage) {
        super(scope, id);

        // 1. IAM Policy
        PolicyStatement statement1 = PolicyStatement.Builder.create()
                .effect(Effect.ALLOW)
                .actions(List.of(
                        "autoscaling:DescribeAutoScalingGroups",
                        "autoscaling:DescribeAutoScalingInstances",
                        "autoscaling:DescribeLaunchConfigurations",
                        "autoscaling:DescribeScalingActivities",
                        "ec2:DescribeImages",
                        "ec2:DescribeInstanceTypes",
                        "ec2:DescribeLaunchTemplateVersions",
                        "ec2:GetInstanceTypesFromInstanceRequirements",
                        "eks:DescribeNodegroup"
                ))
                .resources(List.of("*"))
                .build();

        PolicyStatement statement2 = PolicyStatement.Builder.create()
                .effect(Effect.ALLOW)
                .actions(List.of(
                        "autoscaling:SetDesiredCapacity",
                        "autoscaling:TerminateInstanceInAutoScalingGroup"
                ))
                .resources(List.of("*"))
                .build();

        ManagedPolicy policy = new ManagedPolicy(this, "ClusterAutoscalerPolicy", ManagedPolicyProps.builder()
                .managedPolicyName("AmazonEKSClusterAutoscalerPolicy")
                .document(PolicyDocument.Builder.create().statements(List.of(statement1, statement2)).build())
                .build());

        // 2. Create Service Account
        ServiceAccount sa = cluster.addServiceAccount("ClusterAutoscalerSA",
                ServiceAccountOptions.builder()
                        .name("cluster-autoscaler")
                        .namespace("kube-system")
                        .build());

        policy.attachToRole(sa.getRole());

        // 3. RBAC: ClusterRole
        Map<String, Object> clusterRole = Map.of(
                "apiVersion", "rbac.authorization.k8s.io/v1",
                "kind", "ClusterRole",
                "metadata", Map.of(
                        "name", "cluster-autoscaler",
                        "labels", Map.of(
                                "k8s-addon", "cluster-autoscaler.addons.k8s.io",
                                "k8s-app", "cluster-autoscaler"
                        )
                ),
                "rules", List.of(
                        Map.of(
                                "apiGroups", List.of(""),
                                "resources", List.of("events", "endpoints"),
                                "verbs", List.of("create", "patch")
                        ),
                        Map.of(
                                "apiGroups", List.of(""),
                                "resources", List.of("pods/eviction"),
                                "verbs", List.of("create")
                        ),
                        Map.of(
                                "apiGroups", List.of(""),
                                "resources", List.of("pods/status"),
                                "verbs", List.of("update")
                        ),
                        Map.of(
                                "apiGroups", List.of(""),
                                "resources", List.of("endpoints"),
                                "resourceNames", List.of("cluster-autoscaler"),
                                "verbs", List.of("get", "update")
                        ),
                        Map.of(
                                "apiGroups", List.of(""),
                                "resources", List.of("nodes"),
                                "verbs", List.of("watch", "list", "get", "update")
                        ),
                        Map.of(
                                "apiGroups", List.of(""),
                                "resources", List.of("namespaces", "pods", "services", "replicationcontrollers", "persistentvolumeclaims", "persistentvolumes", "configmaps"),
                                "verbs", List.of("watch", "list", "get")
                        ),
                        Map.of(
                                "apiGroups", List.of(""),
                                "resources", List.of("configmaps"),
                                "resourceNames", List.of("cluster-autoscaler-status"),
                                "verbs", List.of("create", "update")
                        ),
                        Map.of(
                                "apiGroups", List.of("extensions"),
                                "resources", List.of("replicasets", "daemonsets"),
                                "verbs", List.of("watch", "list", "get")
                        ),
                        Map.of(
                                "apiGroups", List.of("policy"),
                                "resources", List.of("poddisruptionbudgets"),
                                "verbs", List.of("watch", "list")
                        ),
                        Map.of(
                                "apiGroups", List.of("apps"),
                                "resources", List.of("statefulsets", "replicasets", "daemonsets"),
                                "verbs", List.of("watch", "list", "get")
                        ),
                        Map.of(
                                "apiGroups", List.of("storage.k8s.io"),
                                "resources", List.of("storageclasses", "csinodes", "csidrivers", "csistoragecapacities"),
                                "verbs", List.of("watch", "list", "get")
                        ),
                        Map.of(
                                "apiGroups", List.of("batch", "extensions"),
                                "resources", List.of("jobs"),
                                "verbs", List.of("get", "list", "watch", "patch")
                        ),
                        Map.of(
                                "apiGroups", List.of("coordination.k8s.io"),
                                "resources", List.of("leases"),
                                "verbs", List.of("create")
                        ),
                        Map.of(
                                "apiGroups", List.of("coordination.k8s.io"),
                                "resources", List.of("leases"),
                                "resourceNames", List.of("cluster-autoscaler"),
                                "verbs", List.of("get", "update")
                        )
                )
        );

        cluster.addManifest("ClusterAutoscalerClusterRole", clusterRole);

        // 4. RBAC: ClusterRoleBinding
        Map<String, Object> clusterRoleBinding = Map.of(
                "apiVersion", "rbac.authorization.k8s.io/v1",
                "kind", "ClusterRoleBinding",
                "metadata", Map.of(
                        "name", "cluster-autoscaler",
                        "labels", Map.of(
                                "k8s-addon", "cluster-autoscaler.addons.k8s.io",
                                "k8s-app", "cluster-autoscaler"
                        )
                ),
                "roleRef", Map.of(
                        "apiGroup", "rbac.authorization.k8s.io",
                        "kind", "ClusterRole",
                        "name", "cluster-autoscaler"
                ),
                "subjects", List.of(Map.of(
                        "kind", "ServiceAccount",
                        "name", sa.getServiceAccountName(),
                        "namespace", sa.getServiceAccountNamespace()
                ))
        );

        cluster.addManifest("ClusterAutoscalerClusterRoleBinding", clusterRoleBinding);

        // 5. Cluster Autoscaler Deployment
        Map<String, Object> deployment = Map.of(
                "apiVersion", "apps/v1",
                "kind", "Deployment",
                "metadata", Map.of(
                        "name", "cluster-autoscaler",
                        "namespace", "kube-system",
                        "labels", Map.of("app", "cluster-autoscaler")
                ),
                "spec", Map.of(
                        "replicas", 1,
                        "selector", Map.of("matchLabels", Map.of("app", "cluster-autoscaler")),
                        "template", Map.of(
                                "metadata", Map.of(
                                        "labels", Map.of("app", "cluster-autoscaler"),
                                        "annotations", Map.of(
                                                "prometheus.io/scrape", "true",
                                                "prometheus.io/port", "8085"
                                        )
                                ),
                                "spec", Map.of(
                                        "priorityClassName", "system-cluster-critical",
                                        "serviceAccountName", sa.getServiceAccountName(),
                                        "containers", List.of(Map.of(
                                                "name", "cluster-autoscaler",
                                                "image", autoscalerImage,
                                                "command", List.of(
                                                        "./cluster-autoscaler",
                                                        "--v=4",
                                                        "--stderrthreshold=info",
                                                        "--cloud-provider=aws",
                                                        "--skip-nodes-with-local-storage=false",
                                                        "--expander=least-waste",
                                                        "--node-group-auto-discovery=asg:tag=k8s.io/cluster-autoscaler/enabled,k8s.io/cluster-autoscaler/" + clusterName
                                                ),
                                                "resources", Map.of(
                                                        "limits", Map.of("cpu", "100m", "memory", "600Mi"),
                                                        "requests", Map.of("cpu", "100m", "memory", "600Mi")
                                                ),
                                                "volumeMounts", List.of(Map.of(
                                                        "name", "ssl-certs",
                                                        "mountPath", "/etc/ssl/certs/ca-certificates.crt",
                                                        "readOnly", true
                                                )),
                                                "securityContext", Map.of(
                                                        "allowPrivilegeEscalation", false,
                                                        "capabilities", Map.of("drop", List.of("ALL")),
                                                        "readOnlyRootFilesystem", true
                                                )
                                        )),
                                        "volumes", List.of(Map.of(
                                                "name", "ssl-certs",
                                                "hostPath", Map.of("path", "/etc/ssl/certs/ca-bundle.crt")
                                        ))
                                )
                        )
                )
        );

        cluster.addManifest("ClusterAutoscalerDeployment", deployment);
    }
}

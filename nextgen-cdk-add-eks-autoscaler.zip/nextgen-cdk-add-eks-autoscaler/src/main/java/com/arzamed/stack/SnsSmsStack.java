package com.arzamed.stack;

import com.arzamed.config.ApplicationConfiguration;
import com.arzamed.config.SnsSmsTopicConfiguration;

import software.amazon.awscdk.CfnOutput;
import software.amazon.awscdk.Stack;
import software.amazon.awscdk.StackProps;
import software.amazon.awscdk.services.events.targets.SnsTopic;
import software.amazon.awscdk.services.sns.Topic;
import software.amazon.awscdk.services.sns.subscriptions.SmsSubscription;
import software.constructs.Construct;

/**
 * SNS infrastructure stack for events with SMS subscription.
 */
public class SnsSmsStack extends Stack {

    public SnsSmsStack(final Construct scope, final String id, final StackProps props,
                       ApplicationConfiguration configuration) {
        super(scope, id, props);

        createSnsTopic(configuration.getSnsSmsTopicConfiguration());
    }

    private void createSnsTopic(SnsSmsTopicConfiguration snsSmsConfig) {
        Topic topic = Topic.Builder.create(this, "EVENTS-TOPIC-SMS")
                .topicName(snsSmsConfig.getName())
                .build();

        var eventsTopic = SnsTopic.Builder.create(topic)
                .build();

        SmsSubscription smsSubscription = SmsSubscription.Builder.create(snsSmsConfig.getPhoneNumber())
                .build();
        eventsTopic.getTopic().addSubscription(smsSubscription);

        CfnOutput.Builder.create(this, "EventsTopicName")
                .description("Events Topic Name")
                .value(eventsTopic.getTopic().getTopicName())
                .build();
    }
}

package com.arzamed.stack;

import software.amazon.awscdk.RemovalPolicy;
import software.amazon.awscdk.services.eks.Cluster;
import software.amazon.awscdk.services.eks.HelmChart;
import software.amazon.awscdk.services.eks.ServiceAccount;
import software.amazon.awscdk.services.eks.ServiceAccountOptions;
import software.amazon.awscdk.services.iam.Effect;
import software.amazon.awscdk.services.iam.PolicyStatement;
import software.amazon.awscdk.services.logs.LogGroup;
import software.amazon.awscdk.services.logs.RetentionDays;
import software.constructs.Construct;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class FluentBitConstruct extends Construct {

    public FluentBitConstruct(final Construct scope, final String id, final Cluster cluster, final String region) {
        super(scope, id);

        // Create CloudWatch Log Group with 1-week retention
        LogGroup logGroup = LogGroup.Builder.create(this, "EksPodsLogGroup")
                .logGroupName("/aws/eks/" + cluster.getClusterName() + "/pods/arzamed-plus365-uat")
                .retention(RetentionDays.ONE_WEEK)
                .removalPolicy(RemovalPolicy.DESTROY)
                .build();

        // Create IAM policy for Fluent Bit
        ServiceAccount fluentBitServiceAccount = cluster.addServiceAccount("FluentBitServiceAccount", ServiceAccountOptions.builder()
                .name("fluent-bit")
                .namespace("kube-system")
                .build());

        fluentBitServiceAccount.addToPrincipalPolicy(PolicyStatement.Builder.create()
                .effect(Effect.ALLOW)
                .actions(Arrays.asList(
                        "logs:CreateLogStream",
                        "logs:CreateLogGroup",
                        "logs:PutLogEvents",
                        "logs:DescribeLogStreams",
                        "logs:DescribeLogGroups"
                ))
                .resources(Arrays.asList("arn:aws:logs:" + region + ":*:log-group:/aws/eks/" + cluster.getClusterName() + "/pods/arzamed-plus365-uat:*"))
                .build());

        // Deploy Fluent Bit using Helm chart
        HelmChart.Builder.create(this, "FluentBitHelmChart")
                .cluster(cluster)
                .chart("fluent-bit")
                .repository("https://fluent.github.io/helm-charts")
                .namespace("kube-system")
                .release("fluent-bit")
                .version("0.47.6")
                .values(Map.of(
                        "serviceAccount", Map.of(
                                "create", false,
                                "name", "fluent-bit",
                                "annotations", Map.of(
                                        "eks.amazonaws.com/role-arn", fluentBitServiceAccount.getRole().getRoleArn()
                                )
                        ),
                        "config", Map.of(
                                "service", "[SERVICE]\n" +
                                           "    Flush 1\n" +
                                           "    Daemon Off\n" +
                                           "    Log_Level info\n" +
                                           "    Parsers_File parsers.conf\n" +
                                           "    HTTP_Server On\n" +
                                           "    HTTP_Listen 0.0.0.0\n" +
                                           "    HTTP_Port 2020\n",
                                "inputs", "[INPUT]\n" +
                                          "    Name tail\n" +
                                          "    Path /var/log/containers/*_arzamed-plus365-uat_*.log\n" +
                                          "    Parser docker_no_time\n" +
                                          "    Tag kube.arzamed-plus365-uat.*\n" +
                                          "    Mem_Buf_Limit 5MB\n" +
                                          "    Skip_Long_Lines On\n",
                                "filters", "[FILTER]\n" +
                                          "    Name kubernetes\n" +
                                          "    Match kube.arzamed-plus365-uat.*\n" +
                                          "    Merge_Log Off\n" +
                                          "    Keep_Log Off\n" +
                                          "    K8S-Logging.Parser On\n" +
                                          "    K8S-Logging.Exclude Off\n" +
                                          "[FILTER]\n" +
                                          "    Name grep\n" +
                                          "    Match kube.arzamed-plus365-uat.*\n" +
                                          "    Regex log ERROR\n",
                                "outputs", "[OUTPUT]\n" +
                                          "    Name cloudwatch_logs\n" +
                                          "    Match kube.arzamed-plus365-uat.*\n" +
                                          "    region " + region + "\n" +
                                          "    log_group_name /aws/eks/" + cluster.getClusterName() + "/pods/arzamed-plus365-uat\n" +
                                          "    log_stream_prefix fluentbit-\n" +
                                          "    auto_create_group true\n" +
                                          "    workers 1\n",
                                "customParsers", "[PARSER]\n" +
                                                "    Name docker_no_time\n" +
                                                "    Format json\n" +
                                                "    Time_Keep Off\n" +
                                                "    Time_Key time\n" +
                                                "    Time_Format %Y-%m-%dT%H:%M:%S.%L\n"
                        )
                ))
                .build();
    }
}

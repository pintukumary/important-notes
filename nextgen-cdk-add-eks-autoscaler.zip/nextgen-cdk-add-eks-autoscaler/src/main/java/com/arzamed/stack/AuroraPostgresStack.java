package com.arzamed.stack;

import java.util.List;

import com.arzamed.config.ApplicationConfiguration;
import com.arzamed.config.AuroraConfiguration;
import com.arzamed.config.IngressRuleConfiguration;
import com.arzamed.config.SecurityGroupConfiguration;

import software.amazon.awscdk.CfnOutput;
import software.amazon.awscdk.SecretValue;
import software.amazon.awscdk.Stack;
import software.amazon.awscdk.StackProps;
import software.amazon.awscdk.services.ec2.IVpc;
import software.amazon.awscdk.services.ec2.Peer;
import software.amazon.awscdk.services.ec2.Port;
import software.amazon.awscdk.services.ec2.SecurityGroup;
import software.amazon.awscdk.services.ec2.SubnetSelection;
import software.amazon.awscdk.services.ec2.Vpc;
import software.amazon.awscdk.services.rds.AuroraPostgresClusterEngineProps;
import software.amazon.awscdk.services.rds.AuroraPostgresEngineVersion;
import software.amazon.awscdk.services.rds.ClusterInstance;
import software.amazon.awscdk.services.rds.Credentials;
import software.amazon.awscdk.services.rds.DatabaseCluster;
import software.amazon.awscdk.services.rds.DatabaseClusterEngine;
import software.amazon.awscdk.services.rds.ParameterGroup;
import software.amazon.awscdk.services.rds.SubnetGroup;
import software.constructs.Construct;

public class AuroraPostgresStack extends Stack {

  public AuroraPostgresStack(final Construct scope, final String id, final StackProps props, Vpc vpc,
      ApplicationConfiguration configuration) {
    super(scope, id, props);

    createAuroraPostgresInstance(vpc, configuration.getAuroraConfiguration());
  }

  private SecurityGroup createDatabaseSecurityGroup(IVpc vpc, SecurityGroupConfiguration dbSecurityGroup) {

    var databaseSecurityGroup = SecurityGroup.Builder.create(this, "DatabaseSG")
        .securityGroupName(dbSecurityGroup.getName())
        .allowAllOutbound(dbSecurityGroup.isAllowAllOutbound())
        .vpc(vpc)
        .build();

    IngressRuleConfiguration ingressRule = dbSecurityGroup.getIngressRule();

    databaseSecurityGroup.addIngressRule(
        Peer.ipv4(ingressRule.getCidr()),
        Port.tcp(ingressRule.getPort()),
        ingressRule.getDescription());

    return databaseSecurityGroup;
  }

  private void createAuroraPostgresInstance(Vpc vpc, AuroraConfiguration auroraConfig) {
    var databaseSecurityGroup = createDatabaseSecurityGroup(vpc, auroraConfig.getSecurityGroupConfig());

    var majorVersion = auroraConfig.getPostgresVersion().split("\\.")[0];
    var engine = DatabaseClusterEngine.auroraPostgres(
        AuroraPostgresClusterEngineProps.builder()
            .version(AuroraPostgresEngineVersion.of(auroraConfig.getPostgresVersion(), majorVersion))
            .build());

    var subnetGroup = SubnetGroup.Builder.create(this, "AuroraSubnetGroup")
        .subnetGroupName("AuroraSubnetGroup")
        .description("SubnetGroup for serverless postgres aurora database")
        .vpc(vpc)
        .vpcSubnets(SubnetSelection.builder().onePerAz(true).build())
        .build();

    DatabaseCluster serverlessV2Cluster = DatabaseCluster.Builder.create(this, "ServerlessAuroraPostgres")
        .engine(engine)
        .clusterIdentifier(auroraConfig.getIdentifier())
        .parameterGroup(ParameterGroup.fromParameterGroupName(this, "ParameterGroup",
            "default.aurora-postgresql" + majorVersion))
        .defaultDatabaseName(auroraConfig.getName())
        .vpc(vpc)
        .securityGroups(List.of(databaseSecurityGroup))
//        .readers(List.of(ClusterInstance.serverlessV2("aurora-serverless-reader")))
        .writer(ClusterInstance.serverlessV2("aurora-serverless-writer"))
        .serverlessV2MinCapacity(auroraConfig.getMinCapacity())
        .serverlessV2MaxCapacity(auroraConfig.getMaxCapacity())
        .subnetGroup(subnetGroup)
        .credentials(Credentials.fromPassword(
            auroraConfig.getUsername(), SecretValue.unsafePlainText(auroraConfig.getPassword())))
        .build();

    CfnOutput.Builder.create(this, "cfnAuroraClusterIdentifier")
            .key("auroraClusterIdentifier")
            .value(serverlessV2Cluster.getClusterIdentifier())
            .exportName("AuroraPostgresStack:DatabaseClusterIdentifier")
            .build();

    CfnOutput.Builder.create(this, "cfnAuroraWriteEndpointAddress")
        .key("auroraWriteEndpointAddress")
        .value(serverlessV2Cluster.getClusterEndpoint().getSocketAddress())
        .build();

    CfnOutput.Builder.create(this, "cfnAuroraReadEndpointAddress")
        .key("auroraReadEndpointAddress")
        .value(serverlessV2Cluster.getClusterReadEndpoint().getSocketAddress())
        .build();
  }

}

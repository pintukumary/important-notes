package com.arzamed.stack;

import com.arzamed.config.ApplicationConfiguration;
import software.amazon.awscdk.App;
import software.amazon.awscdk.Stack;
import software.amazon.awscdk.services.iam.Role;
import software.amazon.awscdk.services.s3.BlockPublicAccess;
import software.amazon.awscdk.services.s3.Bucket;
import software.amazon.awscdk.services.s3.BucketProps;
import software.constructs.Construct;

public class StoragePrivateBucketStack extends Stack {
    public StoragePrivateBucketStack(Construct scope, String id, ApplicationConfiguration configuration) {
        super(scope, id);
        BucketProps props = BucketProps.builder()
                .bucketName(configuration.getStoragePrivateBucketConfiguration().getBucketName())
                .blockPublicAccess(BlockPublicAccess.BLOCK_ALL)
                .publicReadAccess(configuration.getStoragePrivateBucketConfiguration().isPublicAccessAllowed())
                .build();
        new Bucket(this, "StoragePrivateBucket", props);
    }
}

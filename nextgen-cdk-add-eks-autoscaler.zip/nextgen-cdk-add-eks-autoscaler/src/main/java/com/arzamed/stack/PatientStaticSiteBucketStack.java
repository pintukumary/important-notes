package com.arzamed.stack;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import com.arzamed.config.ApplicationConfiguration;
import com.arzamed.config.StaticSiteBucketConfiguration;

import software.amazon.awscdk.CfnOutput;
import software.amazon.awscdk.Fn;
import software.amazon.awscdk.RemovalPolicy;
import software.amazon.awscdk.Stack;
import software.amazon.awscdk.StackProps;
import software.amazon.awscdk.services.cloudfront.CfnCloudFrontOriginAccessIdentity;
import software.amazon.awscdk.services.cloudfront.CfnDistribution;
import software.amazon.awscdk.services.cloudfront.HttpVersion;
import software.amazon.awscdk.services.cloudfront.PriceClass;
import software.amazon.awscdk.services.cloudfront.ViewerProtocolPolicy;
import software.amazon.awscdk.services.cloudfront.BehaviorOptions;
import software.amazon.awscdk.services.cloudfront.CachePolicy;
import software.amazon.awscdk.services.iam.Effect;
import software.amazon.awscdk.services.iam.ManagedPolicy;
import software.amazon.awscdk.services.iam.PolicyStatement;
import software.amazon.awscdk.services.iam.Role;
import software.amazon.awscdk.services.iam.ServicePrincipal;
import software.amazon.awscdk.services.iam.CanonicalUserPrincipal;
import software.amazon.awscdk.services.s3.BlockPublicAccess;
import software.amazon.awscdk.services.s3.Bucket;
import software.amazon.awscdk.services.s3.ObjectOwnership;
import software.constructs.Construct;

/**
 * Patient Static site bucket infrastructure, which deploys patient site content to an S3 bucket.
 */
public class PatientStaticSiteBucketStack extends Stack {

    public static final String S3_FULL_ACCESS = "arn:aws:iam::aws:policy/AmazonS3FullAccess";

    public PatientStaticSiteBucketStack(Construct scope, String id, ApplicationConfiguration configuration,
                                       StackProps stackProps) {
        super(scope, id, stackProps);

        var bucketConfig = configuration.getPatientStaticSiteConfiguration();

        String siteType = "patient";
        var role = createAdminAccessRole(siteType);

        var patientSiteBucket = createStaticSiteBucket("PatientStaticSiteBucket", bucketConfig, role);

        boolean wafEnabled = bucketConfig.isWafEnabled();
        var distribution = deploySiteContentsInBucket(patientSiteBucket, siteType, wafEnabled);
    }

    private Bucket createStaticSiteBucket(String id, StaticSiteBucketConfiguration bucketConfig, Role role) {
        Bucket siteBucket = Bucket.Builder.create(this, id)
                .bucketName(bucketConfig.getBucketName())
                .objectOwnership(ObjectOwnership.BUCKET_OWNER_ENFORCED)
                .websiteIndexDocument(bucketConfig.getWebsiteIndexDocument())
                .websiteErrorDocument(bucketConfig.getWebsiteErrorDocument())
                .publicReadAccess(false)
                .blockPublicAccess(BlockPublicAccess.BLOCK_ALL)
                .removalPolicy(RemovalPolicy.DESTROY)
                .build();

        siteBucket.grantReadWrite(role);

        return siteBucket;
    }

    private Role createAdminAccessRole(String siteType) {
        String name = siteType + "SiteBucketRole";
        return Role.Builder.create(this, name + "-role")
                .assumedBy(ServicePrincipal.Builder.create("cloudformation.amazonaws.com").build())
                .managedPolicies(Collections.singletonList(
                        ManagedPolicy.fromManagedPolicyArn(this, name + "-managed-policy", S3_FULL_ACCESS)))
                .roleName(name)
                .build();
    }

    private CfnDistribution deploySiteContentsInBucket(Bucket siteBucket, String siteType, boolean wafEnabled) {
        String wafWebAclId = null;
        if (wafEnabled) {
            wafWebAclId = Fn.importValue("WafCloudFrontStack:WafAclCloudFrontArn");
        }

        // Create a new OAI
        CfnCloudFrontOriginAccessIdentity oai = CfnCloudFrontOriginAccessIdentity.Builder
                .create(this, siteType + "OriginAccessIdentity")
                .cloudFrontOriginAccessIdentityConfig(
                        CfnCloudFrontOriginAccessIdentity.CloudFrontOriginAccessIdentityConfigProperty.builder()
                                .comment("OAI for " + siteType + " site")
                                .build())
                .build();

        // Update bucket policy to allow CloudFront OAI
        siteBucket.addToResourcePolicy(
                PolicyStatement.Builder.create()
                        .sid("AllowCloudFrontOAIGetObject")
                        .effect(Effect.ALLOW)
                        .principals(List.of(new CanonicalUserPrincipal(oai.getAttrS3CanonicalUserId())))
                        .actions(List.of("s3:GetObject"))
                        .resources(List.of(siteBucket.getBucketArn() + "/*"))
                        .build());

        siteBucket.addToResourcePolicy(
                PolicyStatement.Builder.create()
                        .sid("AllowCloudFrontOAIListBucket")
                        .effect(Effect.ALLOW)
                        .principals(List.of(new CanonicalUserPrincipal(oai.getAttrS3CanonicalUserId())))
                        .actions(List.of("s3:ListBucket"))
                        .resources(List.of(siteBucket.getBucketArn()))
                        .build());

        CfnDistribution distribution = CfnDistribution.Builder
                .create(this, siteType + "SiteDistribution")
                .distributionConfig(
                        CfnDistribution.DistributionConfigProperty.builder()
                                .defaultRootObject("/index.html")
                                .origins(List.of(
                                        CfnDistribution.OriginProperty.builder()
                                                .id("S3Origin")
                                                .domainName(siteBucket.getBucketDomainName())
                                                .s3OriginConfig(
                                                        CfnDistribution.S3OriginConfigProperty.builder()
                                                                .originAccessIdentity(Fn.sub("origin-access-identity/cloudfront/${OAI}", 
                                                                        Map.of("OAI", oai.getRef())))
                                                                .build())
                                                .build()
                                ))
                                .defaultCacheBehavior(
                                        CfnDistribution.DefaultCacheBehaviorProperty.builder()
                                                .targetOriginId("S3Origin")
                                                .viewerProtocolPolicy("redirect-to-https")
                                                .cachePolicyId(CachePolicy.CACHING_OPTIMIZED.getCachePolicyId())
                                                .compress(true)
                                                .allowedMethods(List.of("GET", "HEAD", "OPTIONS"))
                                                .cachedMethods(List.of("GET", "HEAD"))
                                                .build()
                                )
                                .priceClass("PriceClass_All")
                                .httpVersion("http2")
                                .webAclId(wafWebAclId)
                                .enabled(true)
                                .customErrorResponses(List.of(
                                        CfnDistribution.CustomErrorResponseProperty.builder()
                                                .errorCode(403)
                                                .responsePagePath("/index.html")
                                                .responseCode(200)
                                                .errorCachingMinTtl(10.0)
                                                .build(),
                                        CfnDistribution.CustomErrorResponseProperty.builder()
                                                .errorCode(404)
                                                .responsePagePath("/index.html")
                                                .responseCode(200)
                                                .errorCachingMinTtl(10.0)
                                                .build()
                                ))
                                .build()
                )
                .build();

        CfnOutput.Builder.create(this, siteType + "DistributionId")
                .description(siteType + "CloudFront Distribution Id")
                .value(distribution.getRef())
                .build();

        return distribution;
    }

}

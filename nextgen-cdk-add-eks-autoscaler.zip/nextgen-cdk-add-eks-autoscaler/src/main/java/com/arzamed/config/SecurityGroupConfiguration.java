package com.arzamed.config;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SecurityGroupConfiguration {
    private String name;
    private boolean allowAllOutbound;
    private IngressRuleConfiguration ingressRule;
}

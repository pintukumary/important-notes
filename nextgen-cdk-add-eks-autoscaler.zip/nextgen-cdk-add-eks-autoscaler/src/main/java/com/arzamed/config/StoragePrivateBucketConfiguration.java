package com.arzamed.config;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StoragePrivateBucketConfiguration {
    private String bucketName;
    private String removalPolicy;
    private boolean publicAccessAllowed;
}

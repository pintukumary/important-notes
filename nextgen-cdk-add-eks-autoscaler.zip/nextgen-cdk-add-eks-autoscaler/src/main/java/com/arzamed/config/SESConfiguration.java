package com.arzamed.config;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SESConfiguration {
    private String senderEmail;
    private String verifiedEmail;
}

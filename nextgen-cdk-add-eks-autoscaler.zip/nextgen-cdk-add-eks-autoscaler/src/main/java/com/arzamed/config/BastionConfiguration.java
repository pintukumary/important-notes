package com.arzamed.config;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BastionConfiguration {
    private String instanceName;
    private String deviceName;
    private String keyName;
    private String machineImageSsm;
    private String os;
    private String userData;
    private SecurityGroupConfiguration securityGroupConfig;
    private InstanceTypeConfiguration instanceTypeConfig;
}

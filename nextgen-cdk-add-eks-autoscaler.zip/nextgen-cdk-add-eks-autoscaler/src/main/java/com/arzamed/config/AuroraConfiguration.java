package com.arzamed.config;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AuroraConfiguration {
    private String name;
    private String username;
    private String password;
    private String identifier;
    private Integer minCapacity;
    private Integer maxCapacity;

    private SecurityGroupConfiguration securityGroupConfig;
    private String postgresVersion;
    private InstanceTypeConfiguration instanceTypeConfig;
}

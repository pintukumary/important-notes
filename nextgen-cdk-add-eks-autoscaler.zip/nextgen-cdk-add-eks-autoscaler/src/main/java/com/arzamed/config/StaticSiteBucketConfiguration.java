package com.arzamed.config;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StaticSiteBucketConfiguration {
    private String bucketName;
    private String websiteIndexDocument;
    private String websiteErrorDocument;
    private boolean wafEnabled;
    private boolean publicReadAccessAllowed;
    private boolean blockPublicPolicy;
    private boolean blockPublicAcls;
}

package com.arzamed.config;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class IngressRuleConfiguration {
    private String cidr;
    private int port;
    private String description;
}

package com.arzamed.config;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StorageBucketConfiguration {
    private String bucketName;
    private String removalPolicy;
    private boolean publicAccessAllowed;
    private String[] actions;
}

package com.arzamed.config;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EksPrivateClusterConfiguration {
    private String clusterName;
    private String region; // <-- Add this if you plan to use region here
    private boolean enableClusterAutoscaler; // NEW FIELD
    private String autoscalerImage;          // NEW FIELD
    private String metricsServerManifestUrl;

    private String adminRoleName;
    private String kubectlLayerName;
    private String kubernetesVersion;

    private InstanceTypeConfiguration instanceTypeConfig;
    private VpcConfiguration vpcConfiguration;
    private BastionConfiguration bastionConfiguration;
}

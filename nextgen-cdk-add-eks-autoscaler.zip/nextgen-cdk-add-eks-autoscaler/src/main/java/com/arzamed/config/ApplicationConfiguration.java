package com.arzamed.config;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApplicationConfiguration {
    private String region;
    private String defaultAccount;
    private String adminEmail;
    private String cognitoDomain;
    private String[] repositoryNames;

    private AuroraConfiguration auroraConfiguration;
    private StorageBucketConfiguration storageBucketConfiguration;
    private StoragePrivateBucketConfiguration storagePrivateBucketConfiguration;
    private SnsSmsTopicConfiguration snsSmsTopicConfiguration;
    private SESConfiguration sesConfiguration;
    private StaticSiteBucketConfiguration adminStaticSiteConfiguration;
    private StaticSiteBucketConfiguration clientStaticSiteConfiguration;
    private StaticSiteBucketConfiguration patientStaticSiteConfiguration;
    private EksPrivateClusterConfiguration eksPrivateCluster;
}

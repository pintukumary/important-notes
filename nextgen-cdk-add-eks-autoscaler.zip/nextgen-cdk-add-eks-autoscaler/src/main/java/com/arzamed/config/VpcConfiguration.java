package com.arzamed.config;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class VpcConfiguration {
    private String vpcName;
    private String cidrBlock;
    private int maxAzs;
    private int natGateways;
    private List<SubnetConfig> subnets;
}

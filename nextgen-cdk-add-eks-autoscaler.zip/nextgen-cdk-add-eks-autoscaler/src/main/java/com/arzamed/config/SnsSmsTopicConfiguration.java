package com.arzamed.config;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SnsSmsTopicConfiguration {
    private String name;
    private String phoneNumber;
}

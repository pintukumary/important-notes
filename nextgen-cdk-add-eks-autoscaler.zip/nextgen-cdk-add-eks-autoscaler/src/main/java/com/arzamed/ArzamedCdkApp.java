package com.arzamed;

import java.io.InputStream;

import com.arzamed.stack.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.yaml.snakeyaml.LoaderOptions;
import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.constructor.Constructor;

import com.arzamed.config.ApplicationConfiguration;

import software.amazon.awscdk.App;
import software.amazon.awscdk.Environment;
import software.amazon.awscdk.StackProps;
import software.amazon.awscdk.services.ec2.Vpc;

public class ArzamedCdkApp {

    private static final Logger logger = LogManager.getLogger(ArzamedCdkApp.class);

    public ArzamedCdkApp() {
        App app = new App();
        ApplicationConfiguration configuration = loadConfiguration(app);
        StackProps pr = configureStackProperties(configuration);

        instantiateStacks(app, pr, configuration);
        app.synth();
    }

    public static void main(final String[] args) {
        new ArzamedCdkApp();
    }

    private void instantiateStacks(App app, StackProps pr, ApplicationConfiguration configuration) {
        new EcrStack(app, "EcrStack", pr, configuration);

        var eksPrivateClusterStack = new EksPrivateClusterStack(app, "EksPrivateClusterStack", pr,
                configuration);
        Vpc vpc = eksPrivateClusterStack.getVpc();

        var wafCloudFrontStack = new WAFCloudFrontStack(app, "WAFCloudFrontStack", pr);

        var adminStaticSiteBucketStack = new AdminStaticSiteBucketStack(app,
                "AdminStaticSiteBucketStack", configuration, pr);
        if (configuration.getAdminStaticSiteConfiguration().isWafEnabled()) {
            adminStaticSiteBucketStack.addDependency(wafCloudFrontStack);
        }

        var clientStaticSiteBucketStack = new ClientStaticSiteBucketStack(app,
                "ClientStaticSiteBucketStack", configuration, pr);
        if (configuration.getClientStaticSiteConfiguration().isWafEnabled()) {
            clientStaticSiteBucketStack.addDependency(wafCloudFrontStack);
        }

        var patientStaticSiteBucketStack = new PatientStaticSiteBucketStack(app,
                "PatientStaticSiteBucketStack", configuration, pr);
        if (configuration.getClientStaticSiteConfiguration().isWafEnabled()) {
            patientStaticSiteBucketStack.addDependency(wafCloudFrontStack);
        }

        //new WAFRegionalStack(app, "WAFRegionalStack");
        new StorageBucketStack(app, "StorageBucketStack", configuration);
        new StoragePrivateBucketStack(app, "StoragePrivateBucketStack", configuration);
        new AuroraPostgresStack(app, "AuroraPostgresStack", pr, vpc, configuration);

//        String profile = (String) app.getNode().tryGetContext("profile");
//        if (!profile.equals("prod")) {
//            new DatabaseSchedulerLambdaStack(app, "DatabaseScheduleLambdaStack", pr, configuration);
//        }
        //new SnsSmsStack(app, "SnsSmsStack", pr, configuration);
        //new SESStack(app, "SESStack", pr, configuration);
        new ConfigureCognitoStack(app, "CognitoStack", pr, configuration);
    }

    private StackProps configureStackProperties(ApplicationConfiguration configuration) {
        return StackProps.builder()
                .env(Environment.builder()
                        .region(configuration.getRegion())
                        .account(configuration.getDefaultAccount())
                        .build())
                .build();
    }

    private ApplicationConfiguration loadConfiguration(App app) {
        String profile = (String) app.getNode().tryGetContext("profile");

        // default profile uat
        String propertiesFile = "app-properties-uat.yml";
        if (profile.equals("prod")) {
            propertiesFile = "app-properties-prod.yml";
        }

        Constructor constructor = new Constructor(ApplicationConfiguration.class, new LoaderOptions());
        Yaml yaml = new Yaml(constructor);
        InputStream inputStream = this.getClass()
                .getClassLoader()
                .getResourceAsStream(propertiesFile);
        if (inputStream != null) {
            return yaml.load(inputStream);
        } else {
            logger.error("Failed to load configuration: File not found.");
            return new ApplicationConfiguration();
        }
    }

}

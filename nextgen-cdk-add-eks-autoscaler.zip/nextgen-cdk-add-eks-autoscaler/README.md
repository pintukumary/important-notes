# Arzamed CDK Java project:

This is a project for CDK development with Java for Arzamed.

The `cdk.json` file tells the CDK Toolkit how to execute your app.

It is a [Maven](https://maven.apache.org/) based project, so you can open this project with any Maven compatible Java IDE to build and run tests.

## Useful commands

* `mvn package`     compile and run tests
* `cdk ls`          list all stacks in the app
* `cdk synth`       emits the synthesized CloudFormation template
* `cdk deploy`      deploy this stack to your default AWS account/region
* `cdk diff`        compare deployed stack with current state
* `cdk docs`        open CDK documentation
* `cdk bootstrap`   The bootstrap command creates a CloudFormation stack in the environment passed on the command line. Currently, the only resource in that stack is An S3 bucket that holds the file assets and the resulting CloudFormation template to deploy.

## JDK and CDK Versions

- **JDK Version**: 21
- **CDK Version**: 2.128.0

Before deploying the infrastructure, make sure to set the appropriate AWS region and account ID in the `aws-infra-constants.yml` file:

region: us-west-2
defaultAccount: Account-Id

## Project Structure
This project follows the standard Maven directory structure:

* `src/main/java`: Contains Java source files for your CDK application.
* `pom.xml`:  The Maven Project Object Model file, which defines the project configuration and dependencies.
* `src/main/resources/aws-infra-constants.yml`:  YAML file containing configuration details for various AWS resources used in the infrastructure setup.

**Building the Project**:
- Run `mvn clean install` to compile the project and build the JAR file.

**Synthesizing CloudFormation Template**:
- After building the project, run `cdk synth` to generate the CloudFormation template. This command emits the synthesized CloudFormation template based on the CDK code written in Java.

**Deploying the Stack**:
- Once you have the CloudFormation template ready, deploy the stack to your AWS account/region by running `cdk deploy StorageBucketStack`. This command will create or update the stack in your AWS environment based on the generated CloudFormation template.

## Project Configuration

**Generating Public-Private Key files:**

`ssh-keygen -t rsa -b 4096`
When you run this command, it generates a pair of files:

- Private Key: This is typically stored in a file named something like `id_rsa`. This key should be kept secret and securely stored on the client machine you're using to connect to remote servers.

- Public Key: This is stored in a file with a .pub extension, like `id_rsa.pub`. This key can be freely shared and added to the `.ssh/authorized_keys` file on remote servers you wish to connect to securely.

Here's how you can use these files to log in to an AWS EC2 server using SSH:

**1. Copy Public Key to EC2 Server:**

First, copy the contents of the public key file (`id_rsa.pub`) to your clipboard.

```
#!/bin/bash
echo "Copying the SSH Key to the server"
echo -e "Add id_rsa.pub content" >> /home/ubuntu/.ssh/authorized_keys
```

Add above script to userData in `aws-infra-constants.yml` file in userData

Then, SSH into your AWS EC2 instance.
Append the contents of the public key file to the `~/.ssh/authorized_keys` file on the server. You can do this by running:


**2. SSH Login with Private Key:**

Now that your public key is added to the server's `authorized_keys` file, you can SSH into the server using the corresponding private key (`id_rsa`).
Run the SSH command with the private key like this:

`ssh -i /path/to/private/id_rsa username@ec2-instance-ip`

Replace `/path/to/private/id_rsa` with the actual path to your private key file, username with your username on the server, and `ec2-instance-ip` with the public IP address or hostname of your AWS EC2 instance.
